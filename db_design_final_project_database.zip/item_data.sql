INSERT INTO food.item (order_id, food_id)
VALUES (1, 1);

INSERT INTO food.item (order_id, food_id)
VALUES (1, 2);

INSERT INTO food.item (order_id, food_id)
VALUES (1, 4);

INSERT INTO food.item (order_id, food_id)
VALUES (1, 5);

INSERT INTO food.item (order_id, food_id)
VALUES (2, 1);

INSERT INTO food.item (order_id, food_id)
VALUES (2, 6);

INSERT INTO food.item (order_id, food_id)
VALUES (3, 2);

INSERT INTO food.item (order_id, food_id)
VALUES (3, 3);

INSERT INTO food.item (order_id, food_id)
VALUES (3, 4);

INSERT INTO food.item (order_id, food_id)
VALUES (4, 3);

INSERT INTO food.item (order_id, food_id)
VALUES (4, 4);

INSERT INTO food.item (order_id, food_id)
VALUES (4, 5);

INSERT INTO food.item (order_id, food_id)
VALUES (4, 6);

INSERT INTO food.item (order_id, food_id)
VALUES (5, 1);

INSERT INTO food.item (order_id, food_id)
VALUES (5, 2);

INSERT INTO food.item (order_id, food_id)
VALUES (5, 3);

INSERT INTO food.item (order_id, food_id)
VALUES (5, 4);

INSERT INTO food.item (order_id, food_id)
VALUES (5, 5);

INSERT INTO food.item (order_id, food_id)
VALUES (5, 6);