INSERT INTO food.user (first_name, last_name, username, password, email)
VALUES ('Brian', 'Chiu', 'chiub', 'test', 'email0');

INSERT INTO food.user (first_name, last_name, username, password, email)
VALUES ('Sid', 'Rad', 'sidrad', 'pass', 'email1');

INSERT INTO food.user (first_name, last_name, username, password, email)
VALUES ('Tej', 'Patel', 'tpatel', 'postgres', 'email2');

INSERT INTO food.user (first_name, last_name, username, password, email)
VALUES ('Neil', 'Patel', 'np1234', 'mongo', 'email3');

INSERT INTO food.user (username, password, email)
VALUES ('postgres', 'root', 'pg@domain');
