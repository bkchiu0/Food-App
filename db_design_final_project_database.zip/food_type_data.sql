INSERT INTO food.food_type
VALUES ('APPETIZER');

INSERT INTO food.food_type
VALUES ('MAIN');

INSERT INTO food.food_type
VALUES ('SIDE');

INSERT INTO food.food_type
VALUES ('DESSERT');

INSERT INTO food.food_type
VALUES ('DRINK');

INSERT INTO food.food_type
VALUES ('CONDIMENT');